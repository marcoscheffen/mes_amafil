import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronRight, 
  ChevronLeft, 
  Activity, 
  Settings, 
  Database, 
  Truck, 
  AlertCircle, 
  CheckCircle2, 
  Cpu, 
  ArrowRightLeft, 
  BarChart3, 
  Zap,
  ClipboardList,
  MessageSquare,
  Wrench,
  Boxes
} from 'lucide-react';

const COLORS = {
  primary: '#00AA4D', // Amafil Green
  secondary: '#2B57A3', // Institutional Blue
  accent: '#2563EB',
  success: '#16A34A',
  warning: '#D97706',
  danger: '#DC2626',
  bg: '#F5F6FA',
  card: '#FFFFFF',
  text: '#111827',
  textMuted: '#6B7280'
};

// --- Slides Components ---

const CoverSlide = () => (
  <div className="flex flex-col items-center justify-center h-full text-center p-12">
    <motion.div 
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="mb-8"
    >
      <div className="flex items-center gap-3 mb-2">
        <div className="w-12 h-12 bg-[#00AA4D] rounded-lg flex items-center justify-center text-white font-bold text-2xl">A</div>
        <h1 className="text-4xl font-bold tracking-tighter text-[#111827]">
          MES.<span className="text-[#00AA4D]">Amafil</span>
        </h1>
      </div>
    </motion.div>
    
    <motion.h2 
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.3, duration: 0.6 }}
      className="text-5xl md:text-7xl font-bold text-[#111827] mb-6 leading-tight"
    >
      Manufacturing <br />
      <span className="text-[#2B57A3]">Execution System</span>
    </motion.h2>
    
    <motion.p 
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.5, duration: 0.6 }}
      className="text-xl text-[#6B7280] max-w-2xl"
    >
      Transformando o chão de fábrica em um ecossistema digital de alta performance, 
      eliminando o papel e centralizando a inteligência produtiva em tempo real.
    </motion.p>
    
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 1, duration: 1 }}
      className="mt-16 flex gap-4"
    >
      <div className="px-4 py-2 bg-white border border-gray-200 rounded-full text-sm font-medium text-gray-500 shadow-sm">
        Versão 1.0
      </div>
      <div className="px-4 py-2 bg-white border border-gray-200 rounded-full text-sm font-medium text-gray-500 shadow-sm">
        Integração TOTVS Protheus
      </div>
    </motion.div>
  </div>
);

const ProblemSlide = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center h-full p-12">
    <div>
      <h3 className="text-sm font-semibold uppercase tracking-widest text-[#2B57A3] mb-4">O Desafio</h3>
      <h2 className="text-4xl font-bold text-[#111827] mb-6">O Gargalo do Papel</h2>
      <p className="text-lg text-gray-600 mb-8">
        Hoje, o controle da produção depende de formulários físicos, gerando um ciclo lento, 
        sujeito a erros e com baixíssima visibilidade.
      </p>
      
      <ul className="space-y-4">
        {[
          { icon: <Zap className="text-amber-500" />, text: "Retrabalho massivo de digitação no ERP" },
          { icon: <AlertCircle className="text-red-500" />, text: "Risco de perda ou ilegibilidade de dados" },
          { icon: <BarChart3 className="text-blue-500" />, text: "Gestão 'no escuro' durante o turno" },
          { icon: <Settings className="text-gray-500" />, text: "Dificuldade de rastreabilidade rápida" }
        ].map((item, i) => (
          <motion.li 
            key={i}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.2 + i * 0.1 }}
            className="flex items-center gap-3 p-4 bg-white rounded-xl border border-gray-100 shadow-sm"
          >
            {item.icon}
            <span className="font-medium text-gray-700">{item.text}</span>
          </motion.li>
        ))}
      </ul>
    </div>
    
    <div className="bg-white p-8 rounded-3xl border border-gray-200 shadow-xl relative overflow-hidden">
      <div className="absolute top-0 right-0 p-4 opacity-5">
        <ClipboardList size={200} />
      </div>
      <div className="space-y-6 relative">
        <div className="p-4 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
          <div className="h-4 w-3/4 bg-gray-200 rounded mb-2"></div>
          <div className="h-4 w-1/2 bg-gray-200 rounded"></div>
        </div>
        <div className="flex justify-center">
          <ArrowRightLeft className="text-gray-400 rotate-90" />
        </div>
        <div className="p-4 bg-blue-50 border border-blue-100 rounded-lg flex items-center gap-4">
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
            <Settings className="text-blue-600" />
          </div>
          <div>
            <div className="h-4 w-32 bg-blue-200 rounded mb-1"></div>
            <div className="h-3 w-48 bg-blue-200/50 rounded"></div>
          </div>
        </div>
        <p className="text-center text-sm text-gray-400 font-mono italic">
          Fluxo Analógico ➔ Digital (Processo Lento)
        </p>
      </div>
    </div>
  </div>
);

const SolutionSlide = () => (
  <div className="flex flex-col h-full p-12">
    <div className="mb-10">
      <h3 className="text-sm font-semibold uppercase tracking-widest text-[#00AA4D] mb-2">A Solução</h3>
      <h2 className="text-4xl font-bold text-[#111827]">O Ecossistema MES.Amafil</h2>
    </div>
    
    <div className="flex-grow flex flex-col justify-center max-w-5xl mx-auto w-full">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-6">
        {[
          { 
            title: "Importação Inteligente", 
            desc: "O MES consome OPs do Protheus automaticamente, eliminando a impressão de mapas físicos.",
            icon: <Database className="text-blue-500" size={32} />,
            color: "blue"
          },
          { 
            title: "Execução Digital", 
            desc: "Operadores registram turnos, paradas e perdas em tablets, painéis PC e celulares intuitivos.",
            icon: <Activity className="text-[#00AA4D]" size={32} />,
            color: "green"
          },
          { 
            title: "Sincronização Real", 
            desc: "Apontamentos retornam ao ERP instantaneamente após o fechamento eletrônico da OP.",
            icon: <CheckCircle2 className="text-indigo-500" size={32} />,
            color: "indigo"
          }
        ].map((item, i) => (
          <motion.div 
            key={i}
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 + i * 0.1 }}
            className="bg-white p-10 rounded-3xl border border-gray-200 shadow-sm flex flex-col items-center text-center hover:shadow-md transition-shadow"
          >
            <div className={`w-20 h-20 bg-${item.color}-50 rounded-3xl flex items-center justify-center mb-8`}>
              {item.icon}
            </div>
            <h4 className="text-xl font-bold text-gray-900 mb-4">{item.title}</h4>
            <p className="text-gray-600 leading-relaxed">{item.desc}</p>
          </motion.div>
        ))}
      </div>

      {/* Flow Illustration Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="p-8 bg-white rounded-3xl border border-gray-100 shadow-sm flex items-center justify-center gap-12"
      >
        <div className="flex flex-col items-center gap-3">
          <div className="flex items-center gap-2">
            <Database size={20} className="text-gray-400" />
            <ArrowRightLeft size={14} className="text-gray-300" />
            <motion.div 
              animate={{ opacity: [1, 0.4, 1] }} 
              transition={{ repeat: Infinity, duration: 2 }}
              className="w-2 h-2 rounded-full bg-blue-500" 
            />
          </div>
          <p className="text-[11px] font-bold text-gray-400 uppercase tracking-widest">Entrada (OP)</p>
        </div>

        <div className="flex items-center gap-2">
          <div className="h-px bg-gray-200 w-16 relative">
            <ChevronRight size={16} className="text-gray-300 absolute -top-[7.5px] -right-2" />
          </div>
        </div>

        <div className="flex flex-col items-center gap-3">
          <div className="flex gap-3 p-3 bg-gray-50 rounded-xl border border-gray-100">
            <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ repeat: Infinity, duration: 3 }}>
              <Activity size={24} className="text-[#00AA4D]" />
            </motion.div>
            <div className="w-px h-6 bg-gray-200 self-center" />
            <div className="flex gap-2">
              <Zap size={18} className="text-amber-500" />
              <ClipboardList size={18} className="text-[#2B57A3]" />
            </div>
          </div>
          <p className="text-[11px] font-bold text-gray-700 uppercase tracking-widest">Processamento (App MES)</p>
        </div>

        <div className="flex items-center gap-2">
          <div className="h-px bg-gray-200 w-16 relative">
            <ChevronRight size={16} className="text-gray-300 absolute -top-[7.5px] -right-2" />
          </div>
        </div>

        <div className="flex flex-col items-center gap-3">
          <div className="flex items-center gap-2">
            <motion.div 
              animate={{ opacity: [0.4, 1, 0.4] }} 
              transition={{ repeat: Infinity, duration: 2 }}
              className="w-2 h-2 rounded-full bg-indigo-500" 
            />
            <ArrowRightLeft size={14} className="text-gray-300" />
            <CheckCircle2 size={22} className="text-indigo-500" />
          </div>
          <p className="text-[11px] font-bold text-gray-400 uppercase tracking-widest">Saída (Apontamento)</p>
        </div>
      </motion.div>
    </div>
  </div>
);

const DashboardMockup = () => (
  <div className="flex flex-col h-full p-8 bg-[#F5F6FA]">
    <div className="flex items-center justify-between mb-6">
      <div className="flex items-center gap-2">
        <Activity className="text-[#00AA4D]" />
        <h2 className="text-2xl font-bold text-gray-800">Runtime.<span className="text-[#00AA4D]">Dashboard</span></h2>
      </div>
      <div className="flex gap-2">
        <div className="px-3 py-1 bg-green-100 text-green-700 text-xs font-bold rounded-full uppercase">OP: M01376-Active</div>
        <button className="px-4 py-1 bg-[#00AA4D] text-white text-xs font-bold rounded-lg">EXPORTAR DADOS</button>
      </div>
    </div>
    
    <div className="grid grid-cols-4 gap-4 mb-6">
      {[
        { label: "OEE GLOBAL", val: "84.2%", status: "NORMAL", trend: "+2.4%", trendLabel: "ÍNDICE DE PERFORMANCE" },
        { label: "DISPONIBILIDADE", val: "91.5%", status: "INSTÁVEL", trend: "-1.2%", trendLabel: "TAXA DE OPERAÇÃO", warning: true },
        { label: "PERFORMANCE", val: "94.8%", status: "NORMAL", trend: "+0.5%", trendLabel: "RENDIMENTO" },
        { label: "QUALIDADE", val: "98.2%", status: "NORMAL", trend: "+0.1%", trendLabel: "TAXA DE QUALIDADE" }
      ].map((card, i) => (
        <div key={i} className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase">{card.label}</p>
              <p className="text-[10px] text-gray-400">Métricas</p>
            </div>
            <span className={`text-[9px] font-bold px-2 py-0.5 rounded ${card.warning ? 'bg-orange-100 text-orange-600' : 'bg-green-100 text-green-600'}`}>
              {card.status}
            </span>
          </div>
          <div className="text-3xl font-bold text-gray-800 mb-4">{card.val}</div>
          <div className={`text-[10px] font-bold flex items-center gap-1 ${card.trend.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
            <span>{card.trend.startsWith('+') ? '▲' : '▼'} {card.trend}</span>
            <span className="text-gray-400 uppercase ml-1">{card.trendLabel}</span>
          </div>
        </div>
      ))}
    </div>
    
    <div className="grid grid-cols-3 gap-4 flex-grow">
      <div className="col-span-2 bg-white rounded-xl border border-gray-200 p-6 flex flex-col">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-bold text-gray-800">Eficiência de Produção</h3>
          <div className="text-right">
            <span className="text-2xl font-bold text-[#00AA4D]">12.4ms</span>
            <p className="text-[10px] text-gray-400 uppercase">Latência Média</p>
          </div>
        </div>
        <div className="flex-grow flex items-end gap-1 px-2 pb-2">
          {Array.from({ length: 24 }).map((_, i) => (
            <motion.div 
              key={i}
              initial={{ height: 0 }}
              animate={{ height: `${40 + Math.sin(i * 0.5) * 30 + Math.random() * 20}%` }}
              transition={{ delay: i * 0.02, duration: 1 }}
              className="flex-grow bg-[#00AA4D]/10 rounded-t-sm relative group"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-[#00AA4D] opacity-40"></div>
            </motion.div>
          ))}
        </div>
        <div className="flex justify-between mt-2 px-2 text-[10px] text-gray-400 font-mono">
          <span>06:00</span>
          <span>10:00</span>
          <span>14:00</span>
          <span>18:00</span>
        </div>
      </div>
      
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-sm font-bold text-gray-400 uppercase mb-6">Categorias de Erro</h3>
        <div className="space-y-6">
          {[
            { label: "Mecânica", val: 80, color: "bg-red-500", time: "45m" },
            { label: "Elétrica", val: 40, color: "bg-amber-500", time: "30m" },
            { label: "Material", val: 20, color: "bg-blue-500", time: "15m" },
            { label: "Operação", val: 30, color: "bg-violet-500", time: "25m" },
            { label: "Planejada", val: 90, color: "bg-green-500", time: "60m" }
          ].map((bar, i) => (
            <div key={i} className="space-y-2">
              <div className="flex justify-between text-[11px] font-bold">
                <span className="text-gray-600">{bar.label}</span>
                <span className="text-gray-900">{bar.time}</span>
              </div>
              <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${bar.val}%` }}
                  transition={{ delay: 0.5 + i * 0.1, duration: 0.8 }}
                  className={`h-full ${bar.color}`}
                ></motion.div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

const IntegrationSlide = () => (
  <div className="flex flex-col items-center justify-center h-full p-12 overflow-hidden bg-white">
    <div className="text-center mb-16">
      <h3 className="text-sm font-semibold uppercase tracking-widest text-[#2B57A3] mb-2">Integração</h3>
      <h2 className="text-4xl font-bold text-[#111827]">Sincronização Nativa com Protheus</h2>
    </div>
    
    <div className="flex items-center gap-12 relative">
      {/* TOTVS Protheus Side */}
      <motion.div 
        initial={{ x: -100, opacity: 0 }}
        whileInView={{ x: 0, opacity: 1 }}
        className="w-64 p-8 bg-gray-50 border border-gray-200 rounded-3xl flex flex-col items-center text-center shadow-sm"
      >
        <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-4 border border-gray-100">
          <Database className="text-blue-600" />
        </div>
        <h4 className="font-bold text-gray-900">ERP TOTVS PROTHEUS</h4>
        <p className="text-xs text-gray-500 mt-2">Módulo SIGAPCP (SC2)</p>
      </motion.div>
      
      {/* Connector Lines */}
      <div className="flex-grow flex flex-col gap-8 items-center w-64">
        <motion.div 
          animate={{ x: [0, 20, 0] }}
          transition={{ repeat: Infinity, duration: 3 }}
          className="flex flex-col items-center"
        >
          <div className="text-[10px] font-bold text-blue-500 mb-1 uppercase tracking-tight">Importação De Ops</div>
          <div className="w-full h-1 bg-blue-100 rounded-full overflow-hidden relative">
            <motion.div 
              animate={{ left: ['-100%', '100%'] }}
              transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
              className="absolute top-0 h-full w-24 bg-blue-500"
            />
          </div>
        </motion.div>
        
        <motion.div 
          animate={{ x: [0, -20, 0] }}
          transition={{ repeat: Infinity, duration: 3 }}
          className="flex flex-col items-center"
        >
          <div className="text-[10px] font-bold text-green-500 mb-1 uppercase tracking-tight">Apontamentos Reais</div>
          <div className="w-full h-1 bg-green-100 rounded-full overflow-hidden relative">
            <motion.div 
              animate={{ right: ['-100%', '100%'] }}
              transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
              className="absolute top-0 h-full w-24 bg-green-500"
            />
          </div>
        </motion.div>
      </div>

      {/* MES Amafil Side */}
      <motion.div 
        initial={{ x: 100, opacity: 0 }}
        whileInView={{ x: 0, opacity: 1 }}
        className="w-64 p-8 bg-[#00AA4D]/5 border border-[#00AA4D]/20 rounded-3xl flex flex-col items-center text-center shadow-sm"
      >
        <div className="w-16 h-16 bg-[#00AA4D] rounded-2xl shadow-lg flex items-center justify-center mb-4">
          <Activity className="text-white" />
        </div>
        <h4 className="font-bold text-gray-900">SISTEMA MES AMAFIL</h4>
        <p className="text-xs text-gray-500 mt-2">Chão de Fábrica Digital</p>
      </motion.div>
    </div>
    
    <div className="grid grid-cols-2 gap-12 mt-16 text-center max-w-4xl">
      <div className="space-y-2">
        <h5 className="font-bold text-blue-600 uppercase text-xs">O MES Consome</h5>
        <p className="text-sm text-gray-600">No. OP, Produto, Lote Planejado, Validade, QTDE Planejada, BOM (Componentes)</p>
      </div>
      <div className="space-y-2">
        <h5 className="font-bold text-green-600 uppercase text-xs">O MES Devolve</h5>
        <p className="text-sm text-gray-600">Apontamento por Turno, Lote Real, QTDE Produzida, Perdas, Datas Reais de Início/Fim</p>
      </div>
    </div>
  </div>
);

const FeaturesSlide = () => (
  <div className="flex flex-col h-full p-12">
    <div className="mb-12">
      <h3 className="text-sm font-semibold uppercase tracking-widest text-[#2B57A3] mb-2">Funcionalidades</h3>
      <h2 className="text-4xl font-bold text-[#111827]">Inteligência em Todos os Setores</h2>
    </div>
    
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
      {[
        { title: "Manutenção", icon: <Wrench />, desc: "Chamados técnicos via tablet na linha." },
        { title: "Almoxarifado", icon: <Boxes />, desc: "Solicitação de insumos sem deslocamento." },
        { title: "PCP", icon: <BarChart3 />, desc: "Controle total e liberação de OPs." },
        { title: "Mensageria", icon: <MessageSquare />, desc: "Canais de comunicação interna por setor." },
        { title: "Offline-First", icon: <Zap />, desc: "Produção não para sem conexão Wi-Fi." },
        { title: "Multi-Empresa", icon: <Settings />, desc: "Uma plataforma para todas as unidades." },
        { title: "Rastreabilidade", icon: <CheckCircle2 />, desc: "Histórico completo por lote e operador." },
        { title: "OEE Automático", icon: <Activity />, desc: "Cálculo em tempo real por máquina." }
      ].map((feature, i) => (
        <motion.div 
          key={i}
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: i * 0.05 }}
          className="p-6 bg-white border border-gray-100 rounded-2xl shadow-sm hover:shadow-md transition-shadow"
        >
          <div className="w-10 h-10 bg-gray-50 rounded-lg flex items-center justify-center text-[#2B57A3] mb-4">
            {feature.icon}
          </div>
          <h4 className="font-bold text-gray-900 mb-2">{feature.title}</h4>
          <p className="text-sm text-gray-500 leading-relaxed">{feature.desc}</p>
        </motion.div>
      ))}
    </div>
  </div>
);

const ArchitectureSlide = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center h-full p-12">
    <div>
      <h3 className="text-sm font-semibold uppercase tracking-widest text-[#2B57A3] mb-2">Arquitetura</h3>
      <h2 className="text-4xl font-bold text-[#111827] mb-6">Segurança On-Premises</h2>
      <p className="text-lg text-gray-600 mb-8 font-medium">
        Infraestrutura robusta desenhada para a realidade fabril, garantindo 
        disponibilidade máxima.
      </p>
      
      <div className="space-y-4">
        {[
          { label: "Servidor Local", desc: "Processamento dentro da fábrica (Supabase/PostgreSQL)." },
          { label: "Offline First", desc: "Operação garantida mesmo com instabilidade de rede." },
          { label: "PWA (Mobile)", desc: "Instalável em tablets e celulares sem dependência de apps store." },
          { label: "Segurança", desc: "Isolamento de dados por empresa (RLS) e TLS." }
        ].map((item, i) => (
          <div key={i} className="flex gap-4">
            <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center text-green-600 shrink-0">
              <CheckCircle2 size={14} />
            </div>
            <div>
              <h5 className="font-bold text-gray-900 text-sm">{item.label}</h5>
              <p className="text-sm text-gray-500">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
    
    <div className="relative">
      <div className="bg-slate-900 rounded-3xl p-8 text-white font-mono text-xs shadow-2xl">
        <div className="flex gap-2 mb-4">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
        </div>
        <div className="space-y-2 opacity-80">
          <p className="text-blue-400">// Stack Tecnológico</p>
          <p><span className="text-purple-400">const</span> <span className="text-yellow-400">frontend</span> = [<span className="text-green-400">"Next.js 15"</span>, <span className="text-green-400">"Tailwind"</span>];</p>
          <p><span className="text-purple-400">const</span> <span className="text-yellow-400">backend</span> = [<span className="text-green-400">"Node.js 22"</span>, <span className="text-green-400">"Fastify"</span>];</p>
          <p><span className="text-purple-400">const</span> <span className="text-yellow-400">database</span> = [<span className="text-green-400">"PostgreSQL 16"</span>, <span className="text-green-400">"Supabase"</span>];</p>
          <br />
          <p className="text-blue-400">// Deployment</p>
          <p><span className="text-yellow-400">containerRuntime</span>: <span className="text-green-400">"Docker Compose"</span>,</p>
          <p><span className="text-yellow-400">proxyServer</span>: <span className="text-green-400">"Nginx"</span>,</p>
          <p><span className="text-yellow-400">operatingSystem</span>: <span className="text-green-400">"Ubuntu Server 24.04"</span></p>
        </div>
      </div>
      
      {/* Decorative chips */}
      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 4 }}
        className="absolute -top-4 -right-4 bg-white p-4 rounded-2xl shadow-lg border border-gray-100 flex items-center gap-3"
      >
        <div className="p-2 bg-blue-50 rounded-lg"><Cpu className="text-blue-600" size={20} /></div>
        <div className="font-bold text-gray-800 text-sm">Industrial Edge</div>
      </motion.div>
    </div>
  </div>
);

const ColosArchitectureSlide = () => (
  <div className="flex flex-col h-full p-12 overflow-hidden bg-white">
    <div className="mb-8 flex justify-between items-start">
      <div className="text-left">
        <h3 className="text-sm font-semibold uppercase tracking-widest text-[#5B2C6F] mb-2 font-mono">Arquitetura ISA-95 / Cenário CoLOS</h3>
        <h2 className="text-4xl font-bold text-[#111827]">Integração MES Amafil + CoLOS</h2>
      </div>
      <img 
        src="https://neutechpackaging.com/new2026/wp-content/uploads/2025/04/markem-imaje-logo-full-color.png" 
        alt="Markem-Imaje Logo" 
        className="h-12 object-contain"
        referrerPolicy="no-referrer"
      />
    </div>

    <div className="flex-grow flex flex-col justify-center max-w-5xl mx-auto w-full relative">
      <div className="bg-gray-50 p-8 rounded-[2rem] border border-gray-100 shadow-inner relative">
        <div className="space-y-3">
          {[
            { level: "Nível 4", title: "Empresa (ERP)", items: ["Gestão Corporativa / Protheus"], color: "bg-[#1B2631]" },
            { level: "Nível 3", title: "Fábrica (MES + WMS)", items: ["MES Amafil", "Gestão de Dados", "Banco de Dados Central"], color: "bg-[#00AA4D]" },
            { level: "Nível 2", title: "Linha (CoLOS)", items: ["Design de Mensagem", "Relatórios", "Produção HMI", "Aplicativo Móvel"], color: "bg-[#5B2C6F]" },
            { level: "Nível 1", title: "Dispositivo", items: ["Scanners", "Codificadores", "Etiquetadores", "Visão", "CLP"], color: "bg-[#2E4053]" },
            { level: "Nível 0", title: "Esteira", items: ["Item", "Caixa", "Palete"], color: "bg-[#5D6D7E]" }
          ].map((lvl, index) => (
            <motion.div 
              key={lvl.level}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center gap-4"
            >
              <div className={`w-28 shrink-0 flex items-center justify-center text-white font-bold text-[10px] py-3 rounded-xl shadow-sm ${lvl.color}`}>
                {lvl.level}
              </div>
              <div className="flex-grow bg-white border border-gray-100 p-3 rounded-xl flex items-center gap-4 shadow-sm">
                <div className="font-bold text-gray-800 text-xs min-w-[140px] border-r border-gray-100 pr-4">{lvl.title}</div>
                <div className="flex flex-wrap gap-2">
                  {lvl.items.map((item, i) => (
                    <span key={i} className="px-2 py-1 bg-gray-50 text-gray-500 text-[10px] rounded-md border border-gray-100">{item}</span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        
        {/* Flow Indicators */}
        <div className="absolute right-8 top-10 bottom-10 w-1 bg-gray-200/50 rounded-full flex flex-col justify-between py-10">
          <div className="w-3 h-3 bg-indigo-500 rounded-full -ml-1 border-2 border-white shadow-sm" />
          <div className="w-3 h-3 bg-green-500 rounded-full -ml-1 border-2 border-white shadow-sm" />
          <div className="w-3 h-3 bg-purple-500 rounded-full -ml-1 border-2 border-white shadow-sm" />
        </div>
      </div>
      
      <div className="mt-8 grid grid-cols-2 gap-8">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-purple-50 rounded-lg"><ArrowRightLeft className="text-purple-600" size={20} /></div>
          <div>
            <h4 className="font-bold text-gray-900 text-sm mb-1 uppercase tracking-tighter">Fluxo de Dados</h4>
            <p className="text-xs text-gray-500">Comandos automáticos e feedback de produção.</p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <div className="p-2 bg-gray-50 rounded-lg"><Truck className="text-gray-400" size={20} /></div>
          <div>
            <h4 className="font-bold text-gray-900 text-sm mb-1 uppercase tracking-tighter">Fluxo de Produto</h4>
            <p className="text-xs text-gray-500">Movimentação física do item ao palete final.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const ColosBenefitsSlide = () => (
  <div className="flex flex-col h-full p-12 bg-white">
    <div className="mb-12 flex justify-between items-end">
      <div>
        <h3 className="text-sm font-semibold uppercase tracking-widest text-[#5B2C6F] mb-2 font-mono">Value Proposition</h3>
        <h2 className="text-4xl font-bold text-[#111827]">Vantagens da Sincronização MES + CoLOS</h2>
      </div>
      <div className="bg-[#5B2C6F] text-white px-6 py-2 rounded-xl font-black italic tracking-tighter text-2xl">
        CoLOS®
      </div>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center flex-grow">
      <div className="space-y-8">
        {[
          { 
            title: "Configuração Zero-Touch", 
            icon: <Zap className="text-amber-500" />, 
            desc: "Envio automático das informações para as impressoras sem necessidade de intervenção manual do operador." 
          },
          { 
            title: "Confiabilidade Total", 
            icon: <CheckCircle2 className="text-[#00AA4D]" />, 
            desc: "Redução drástica de erros humanos e garantia de que o lote/validade impresso é exatamente o da OP." 
          },
          { 
            title: "Monitoramento em Tempo Real", 
            icon: <Activity className="text-blue-500" />, 
            desc: "O MES obtém status das impressoras, quantidade de impressões e telemetria detalhada de funcionamento." 
          }
        ].map((benefit, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.15 }}
            className="flex gap-5"
          >
            <div className="w-14 h-14 bg-gray-50 rounded-2xl flex items-center justify-center shrink-0 border border-gray-100">
              {benefit.icon}
            </div>
            <div>
              <h4 className="text-xl font-bold text-gray-900 mb-2">{benefit.title}</h4>
              <p className="text-gray-600 leading-relaxed">{benefit.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="bg-[#5B2C6F]/5 p-8 rounded-[3rem] border border-purple-100 flex flex-col items-center justify-center text-center relative overflow-hidden">
        <div className="absolute -top-12 -right-12 w-32 h-32 bg-white/50 rounded-full blur-2xl"></div>
        <motion.div 
          animate={{ scale: [1, 1.05, 1] }} 
          transition={{ repeat: Infinity, duration: 4 }}
          className="mb-8"
        >
          <div className="w-32 h-32 bg-white rounded-full shadow-lg flex items-center justify-center mb-4 relative p-4">
            <img 
              src="https://marksys.com.br/wp-content/uploads/2025/05/colos-flower-400x400-25.jpg" 
              alt="CoLOS Logo"
              className="w-full h-full object-contain"
              onError={(e) => {
                // Fallback icon if image fails
                e.currentTarget.style.display = 'none';
              }}
            />
            <Settings size={40} className="text-[#5B2C6F] absolute opacity-20" />
            <motion.div 
              animate={{ rotate: 360 }} 
              transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
              className="absolute inset-0 border-2 border-dashed border-purple-200 rounded-full"
            />
          </div>
        </motion.div>
        <h4 className="text-lg font-bold text-[#5B2C6F] mb-4">Conectividade Bidirecional</h4>
        <div className="grid grid-cols-2 gap-4 w-full">
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-purple-100">
            <div className="text-[10px] font-bold text-gray-400 uppercase mb-2">MES ➔ CoLOS</div>
            <p className="text-[11px] font-medium text-gray-700">Setup Automático, Lote, Validade e Templates</p>
          </div>
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-purple-100">
            <div className="text-[10px] font-bold text-gray-400 uppercase mb-2">CoLOS ➔ MES</div>
            <p className="text-[11px] font-medium text-gray-700">Status, Contagem de Impressão e Saúde do Ativo</p>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const MarkemImajeProductsSlide = () => (
  <div className="flex flex-col h-full p-12 bg-white">
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center flex-grow">
      <div>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-[#5B2C6F] rounded-lg"></div>
          <div>
            <h3 className="text-sm font-bold text-[#5B2C6F] uppercase tracking-tighter">Markem-Imaje</h3>
            <p className="text-[10px] text-gray-400 font-bold uppercase">Soma Solution • Distribuidor Oficial</p>
          </div>
        </div>
        
        <h2 className="text-4xl font-bold text-[#111827] mb-8">Codificação e Marcação de Produtos</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[
            "Impressoras Inkjet",
            "Termotransferência",
            "Impressoras Laser",
            "Alta Resolução",
            "Jato de Tinta Térmico",
            "Grandes Caracteres",
            "Aplicadoras de Etiquetas",
            "Visão e Inspeção"
          ].map((item, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex items-center gap-2 p-3 bg-gray-50 rounded-xl border border-gray-100"
            >
              <CheckCircle2 size={16} className="text-[#5B2C6F] shrink-0" />
              <span className="text-sm font-medium text-gray-700">{item}</span>
            </motion.div>
          ))}
        </div>
      </div>

      <div className="relative group">
        <div className="absolute inset-0 bg-[#5B2C6F]/5 rounded-[3rem] blur-3xl group-hover:bg-[#5B2C6F]/10 transition-all duration-700"></div>
        <div className="bg-white border border-gray-100 rounded-[2.5rem] p-10 shadow-xl relative overflow-hidden backdrop-blur-sm">
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#5B2C6F]/5 rounded-bl-full"></div>
          <div className="flex flex-col items-center gap-6">
            <div className="grid grid-cols-2 gap-4 w-full">
              <motion.div 
                whileHover={{ y: -5 }}
                className="p-5 bg-white rounded-2xl border border-purple-100 shadow-sm flex flex-col items-center text-center"
              >
                <div className="text-xl font-black text-gray-900 mb-1">X30</div>
                <div className="text-[9px] text-[#5B2C6F] uppercase font-bold mb-2">SmartDate TTO</div>
                <p className="text-[10px] text-gray-500 leading-tight">Codificação térmica compacta para embalagens.</p>
              </motion.div>

              <motion.div 
                whileHover={{ y: -5 }}
                className="p-5 bg-white rounded-2xl border border-purple-100 shadow-sm flex flex-col items-center text-center"
              >
                <div className="text-xl font-black text-gray-900 mb-1">X45</div>
                <div className="text-[9px] text-[#5B2C6F] uppercase font-bold mb-2">SmartDate TTO</div>
                <p className="text-[10px] text-gray-500 leading-tight">Alta performance e gerenciamento de fita.</p>
              </motion.div>
              
              <motion.div 
                whileHover={{ y: -5 }}
                className="p-5 bg-white rounded-2xl border border-purple-100 shadow-sm flex flex-col items-center text-center"
              >
                <div className="text-xl font-black text-gray-900 mb-1">9330</div>
                <div className="text-[9px] text-blue-600 uppercase font-bold mb-2">Inkjet (CIJ)</div>
                <p className="text-[10px] text-gray-500 leading-tight">Versatilidade e baixo custo operacional.</p>
              </motion.div>

              <motion.div 
                whileHover={{ y: -5 }}
                className="p-5 bg-white rounded-2xl border border-purple-100 shadow-sm flex flex-col items-center text-center"
              >
                <div className="text-xl font-black text-gray-900 mb-1">2200</div>
                <div className="text-[9px] text-indigo-600 uppercase font-bold mb-2">Print & Apply</div>
                <p className="text-[10px] text-gray-500 leading-tight">Rotulagem automática de alta velocidade.</p>
              </motion.div>
            </div>
            
            <div className="w-full space-y-3 px-2">
              <div className="flex justify-between items-center text-[10px] font-bold text-gray-400 uppercase">
                <span>Eficiência de Linha</span>
                <span className="text-[#00AA4D]">99.8% UP-TIME</span>
              </div>
              <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: '99.8%' }} 
                  transition={{ delay: 1, duration: 2 }} 
                  className="h-full bg-gradient-to-r from-[#5B2C6F] to-[#00AA4D]"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div className="mt-8 border-t border-gray-100 pt-6 flex justify-between items-center mb-12">
      <div className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">
        Solution for Food & Beverage Coding
      </div>
      <div className="flex gap-4 items-center">
        <span className="text-[10px] font-bold text-[#5B2C6F]">MARKEM-IMAJE.COM</span>
        <span className="text-gray-300">|</span>
        <span className="text-[10px] font-bold text-[#2B57A3]">SOMASOLUTION.COM.BR</span>
      </div>
    </div>
  </div>
);

const DatecHardwareSlide = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center h-full p-12">
    <div>
      <h3 className="text-sm font-semibold uppercase tracking-widest text-[#EE7101] mb-2 font-mono">Hardware & Conectividade</h3>
      <h2 className="text-4xl font-bold text-[#111827] mb-6">DATEC: A Ponte para o IOT</h2>
      <p className="text-lg text-gray-600 mb-8">
        A Datec Solution fornece a camada física de automação, conectando sensores, 
        balanças e CLPs diretamente ao MES via Gateways Industriais.
      </p>
      
      <div className="space-y-6">
        {[
          { title: "Gateway Datec", desc: "Coleta e processamento de borda com buffer local (offline-ready).", icon: <Cpu className="text-[#EE7101]" /> },
          { title: "Monitoramento de Máquinas", desc: "Ciclos, status e alarmes capturados em tempo real (Modbus/OPC-UA).", icon: <Activity className="text-blue-500" /> },
          { title: "Infraestrutura Elétrica", desc: "Painéis, clausuras IP65 e suportes robustos para o ambiente industrial.", icon: <Settings className="text-gray-500" /> }
        ].map((item, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="flex gap-4 p-4 bg-white rounded-2xl border border-gray-100 shadow-sm"
          >
            <div className="w-12 h-12 bg-gray-50 rounded-xl flex items-center justify-center shrink-0">
              {item.icon}
            </div>
            <div>
              <h4 className="font-bold text-gray-900 text-sm">{item.title}</h4>
              <p className="text-sm text-gray-500">{item.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
    
    <div className="bg-[#111827] rounded-[3rem] p-8 shadow-2xl relative overflow-hidden flex items-center justify-center min-h-[400px]">
      <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_50%_50%,_#EE7101_0%,_transparent_70%)]"></div>
      <div className="relative flex flex-col items-center">
        {/* Simple Gateway Illustration */}
        <motion.div 
          animate={{ scale: [1, 1.02, 1] }}
          transition={{ repeat: Infinity, duration: 4 }}
          className="w-48 h-64 bg-gray-800 rounded-2xl border-4 border-gray-700 p-4 shadow-inner relative"
        >
          <div className="w-full h-8 bg-gray-700 rounded mb-4 flex items-center px-4 gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-red-500"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
          </div>
          <div className="space-y-3">
            <div className="h-1 bg-gray-600 rounded-full w-full"></div>
            <div className="h-1 bg-gray-600 rounded-full w-3/4"></div>
            <div className="h-1 bg-gray-600 rounded-full w-full"></div>
            <div className="h-1 bg-gray-600 rounded-full w-1/2"></div>
          </div>
          <div className="absolute bottom-4 inset-x-4 flex justify-between">
            <div className="w-8 h-8 bg-gray-700 rounded-md border border-gray-600 flex items-center justify-center text-[8px] text-gray-400 font-bold">ETH</div>
            <div className="w-8 h-8 bg-gray-700 rounded-md border border-gray-600 flex items-center justify-center text-[8px] text-gray-400 font-bold">MBUS</div>
          </div>
        </motion.div>
        <div className="mt-8 text-center">
          <p className="text-[#EE7101] font-mono text-xs font-bold uppercase tracking-widest">Gateway Industrial Datec</p>
          <p className="text-gray-500 text-[10px] uppercase font-bold mt-1">Conectividade Robusta</p>
        </div>
      </div>
    </div>
  </div>
);

const DatecPartnershipSlide = () => (
  <div className="flex flex-col items-center justify-center h-full p-24 bg-white text-center">
    <motion.div 
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="mb-16 flex flex-col items-center"
    >
      <div className="relative p-8 bg-gray-950 rounded-3xl mb-8 shadow-2xl">
        <img 
          src="https://www.datecsolution.com/img/datec-solution.webp" 
          alt="Datec Solution Logo" 
          className="h-24 object-contain brightness-0 invert"
          referrerPolicy="no-referrer"
        />
      </div>
      <span className="text-[#EE7101] font-bold uppercase tracking-[0.3em] text-sm">Parceiro Estratégico</span>
    </motion.div>

    <div className="grid grid-cols-2 gap-16 max-w-4xl">
      <div className="text-left">
        <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
           <Zap className="text-[#EE7101]" /> Eficiência de Campo
        </h3>
        <p className="text-gray-600 text-sm leading-relaxed">
          Instalação de sensores de alta precisão em embaladoras, 
          enfardadeiras e pesagem, garantindo que o MES receba dados 
          auditáveis sem intervenção humana.
        </p>
      </div>
      <div className="text-left">
        <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
          <Truck className="text-blue-600" /> Soluções Completas
        </h3>
        <p className="text-gray-600 text-sm leading-relaxed">
          Dos suportes metálicos às clausuras elétricas, a Datec entrega 
          o "Turn-key" da conectividade industrial, 
          permitindo que a TI se foque na inteligência.
        </p>
      </div>
    </div>

    <div className="mt-20 flex items-center gap-12 grayscale opacity-50">
      <div className="text-sm font-black text-gray-400 font-mono tracking-tighter">DATEC.<span className="text-gray-300">SOLUTION</span></div>
    </div>
  </div>
);

const FlowSlide = () => (
  <div className="flex flex-col h-full p-8 pb-24 bg-gray-50 overflow-hidden">
    <div className="mb-6 text-center">
      <h3 className="text-sm font-semibold uppercase tracking-widest text-[#00AA4D] mb-1 font-mono">Infraestrutura & Fluxo de Dados</h3>
      <h2 className="text-3xl font-bold text-[#111827]">Ecossistema MES.Amafil</h2>
    </div>

    <div className="flex-grow grid grid-cols-12 gap-4 relative">
      <div className="col-span-12 flex justify-center mb-2">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="px-6 py-3 bg-gray-900 text-white rounded-2xl shadow-xl border border-gray-700 flex flex-col items-center"
        >
          <Database size={20} className="mb-1 text-blue-400" />
          <span className="text-xs font-black uppercase tracking-widest">TOTVS Protheus</span>
          <span className="text-[10px] text-gray-400 uppercase font-bold tracking-tighter">ERP Corporativo (SIGAPCP)</span>
        </motion.div>
      </div>

      <div className="col-span-12 flex justify-center h-8 -mt-2">
        <div className="w-px bg-dashed border-l border-gray-300 h-full relative">
          <ArrowRightLeft className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-blue-400 rotate-90" size={14} />
        </div>
      </div>

      <div className="col-span-3">
        <div className="h-full bg-white rounded-3xl border border-gray-200 p-4 shadow-sm flex flex-col justify-center gap-4">
          <div className="px-3 py-1 bg-gray-100 rounded-full text-[9px] font-bold text-gray-400 text-center uppercase tracking-widest mb-2">Perfis (PWA)</div>
          {[
            { label: "PCP", icon: <BarChart3 size={16} /> },
            { label: "Operação", icon: <Boxes size={16} /> },
            { label: "Manutenção", icon: <Wrench size={16} /> },
            { label: "Gestão", icon: <Settings size={16} /> }
          ].map((u, i) => (
            <div key={i} className="flex items-center gap-3 p-2 bg-gray-50 rounded-xl border border-gray-100">
              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center text-[#00AA4D] shadow-sm">{u.icon}</div>
              <span className="text-xs font-bold text-gray-700">{u.label}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="col-span-6 flex flex-col gap-4">
        <div className="bg-[#00AA4D] rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-bl-full"></div>
          <div className="relative flex justify-between items-center mb-4">
            <div>
              <h4 className="text-lg font-black uppercase tracking-tighter">Servidor MES</h4>
              <p className="text-[10px] text-green-100 uppercase font-bold tracking-widest opacity-70">On-Premises Runtime</p>
            </div>
            <div className="flex gap-2">
              <div className="px-2 py-1 bg-white/20 rounded-md text-[9px] font-bold">NODE.JS 22</div>
              <div className="px-2 py-1 bg-white/20 rounded-md text-[9px] font-bold">FASTIFY</div>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white/10 p-3 rounded-2xl flex flex-col items-center">
              <Activity size={20} className="mb-2" />
              <span className="text-[9px] font-bold uppercase">Realtime</span>
            </div>
            <div className="bg-white/10 p-3 rounded-2xl flex flex-col items-center border border-white/20">
              <Database size={20} className="mb-2" />
              <span className="text-[9px] font-bold uppercase">Auth / DB</span>
            </div>
            <div className="bg-white/10 p-3 rounded-2xl flex flex-col items-center">
              <ArrowRightLeft size={20} className="mb-2" />
              <span className="text-[9px] font-bold uppercase">Proxy</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm flex items-center gap-4">
            <div className="p-3 bg-blue-50 rounded-xl"><Database className="text-blue-600" size={24} /></div>
            <div>
              <h5 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Central DB</h5>
              <p className="text-xs font-bold text-gray-800">PostgreSQL 16</p>
            </div>
          </div>
          <div className="bg-white rounded-2xl border border-gray-200 p-4 shadow-sm flex items-center gap-4">
            <div className="p-3 bg-red-50 rounded-xl"><Activity className="text-red-500" size={24} /></div>
            <div>
              <h5 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Queue & Cache</h5>
              <p className="text-xs font-bold text-gray-800">Redis / BullMQ</p>
            </div>
          </div>
        </div>
      </div>

      <div className="col-span-3">
        <div className="h-full bg-[#111827] rounded-3xl p-6 text-white flex flex-col justify-between">
          <div>
            <h4 className="text-sm font-bold mb-4 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
              Dispositivos
            </h4>
            <div className="space-y-4">
              {[
                { label: "Painéis Industriais", type: "HMI" },
                { label: "Tablets Linha", type: "Mobile" },
                { label: "Smartphones", type: "PWA" }
              ].map((d, i) => (
                <div key={i} className="flex justify-between items-center bg-white/5 p-3 rounded-xl border border-white/5">
                  <span className="text-xs font-medium text-gray-400">{d.label}</span>
                  <span className="text-[9px] font-black bg-white/10 px-2 py-1 rounded text-white italic">{d.type}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-auto pt-6 border-t border-white/5 text-center">
            <p className="text-[9px] text-gray-500 uppercase tracking-[0.2em]">Interface Unificada</p>
          </div>
        </div>
      </div>

      <div className="col-span-12 mt-2">
        <div className="bg-gray-200/50 rounded-[2.5rem] p-6 border-t-2 border-gray-300 relative">
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-gray-900 border border-gray-700 text-white text-[9px] font-black uppercase rounded-full shadow-lg">
            Hardware & Automação (IOT)
          </div>
          
          <div className="grid grid-cols-5 gap-4">
            <div className="col-span-4 grid grid-cols-4 gap-4">
              {["Empacotadora", "Balança", "Costuradeira", "Enfardadeira"].map((m, i) => (
                <div key={i} className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm flex flex-col items-center gap-2">
                  <div className="w-10 h-10 bg-gray-50 rounded-lg flex items-center justify-center text-gray-400"><Boxes size={20} /></div>
                  <span className="text-[10px] font-bold text-gray-700 uppercase tracking-tighter">{m}</span>
                </div>
              ))}
            </div>
            
            <div className="bg-[#EE7101] rounded-2xl p-4 text-white shadow-lg flex flex-col items-center justify-center text-center">
              <Cpu size={24} className="mb-2" />
              <h5 className="text-[10px] font-black uppercase mb-1">Gateway IoT</h5>
              <p className="text-[9px] leading-tight text-white/80">Buffer Local <br/> Modbus/OPC</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

const ConclusionSlide = () => (
  <div className="flex flex-col items-center justify-center h-full text-center p-12 bg-white relative overflow-hidden">
    <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-[#00AA4D] via-[#2B57A3] to-[#5B2C6F]"></div>
    <div className="absolute -right-24 -bottom-24 w-96 h-96 bg-gray-50 rounded-full blur-3xl opacity-50"></div>
    
    <motion.div 
      initial={{ scale: 0.5, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: "spring", damping: 15 }}
      className="w-24 h-24 bg-[#00AA4D] rounded-[2rem] flex items-center justify-center text-white mb-10 shadow-2xl shadow-green-200 relative z-10"
    >
      <CheckCircle2 size={48} />
    </motion.div>
    
    <div className="relative z-10 max-w-3xl">
      <h2 className="text-5xl font-black text-[#111827] mb-6 leading-tight tracking-tighter">
        Eficiência que se vê <br />
        <span className="text-[#00AA4D]">na prática.</span>
      </h2>
      <p className="text-xl text-gray-500 mb-12 leading-relaxed">
        O MES Amafil é mais que um software, é a evolução da nossa maturidade produtiva. 
        Dados precisos, decisões rápidas e um chão de fábrica 100% conectado.
      </p>
    </div>
    
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl relative z-10">
      {[
        { label: "Performance", val: "+15%", desc: "Ganho médio em OEE", color: "text-[#00AA4D]", bg: "bg-green-50" },
        { label: "Decisões Ágeis", val: "LIVE", desc: "Dados em tempo real", color: "text-[#2B57A3]", bg: "bg-blue-50" },
        { label: "Governança", val: "100%", desc: "Rastreabilidade Digital", color: "text-purple-600", bg: "bg-purple-50" }
      ].map((metric, i) => (
        <motion.div 
          key={i}
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 + i * 0.1 }}
          className="p-8 bg-white rounded-3xl border border-gray-100 shadow-sm hover:shadow-lg transition-all border-b-4 border-b-gray-100 hover:border-b-[#00AA4D]/30"
        >
          <div className={`text-4xl font-black ${metric.color} mb-2 tracking-tighter`}>{metric.val}</div>
          <div className="text-xs font-black text-gray-900 uppercase tracking-widest mb-1">{metric.label}</div>
          <div className="text-[10px] text-gray-400 font-medium uppercase">{metric.desc}</div>
        </motion.div>
      ))}
    </div>
    
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 1 }}
      className="mt-16 flex flex-col items-center"
    >
      <div className="h-px w-12 bg-gray-200 mb-6"></div>
      <p className="text-sm font-bold text-gray-400 uppercase tracking-[0.4em]">Indústria 4.0 Amafil</p>
    </motion.div>
  </div>
);

// --- Main Presentation Component ---

const slides = [
  { id: 'cover', component: <CoverSlide />, bg: 'bg-white' },
  { id: 'problem', component: <ProblemSlide />, bg: 'bg-[#F9FAFB]' },
  { id: 'solution', component: <SolutionSlide />, bg: 'bg-white' },
  { id: 'dashboard', component: <DashboardMockup />, bg: 'bg-[#F5F6FA]' },
  { id: 'integration', component: <IntegrationSlide />, bg: 'bg-white' },
  { id: 'features', component: <FeaturesSlide />, bg: 'bg-[#F9FAFB]' },
  { id: 'architecture', component: <ArchitectureSlide />, bg: 'bg-white' },
  { id: 'flow', component: <FlowSlide />, bg: 'bg-gray-50' },
  { id: 'datec-hw', component: <DatecHardwareSlide />, bg: 'bg-white' },
  { id: 'datec-partner', component: <DatecPartnershipSlide />, bg: 'bg-white' },
  { id: 'colos-arch', component: <ColosArchitectureSlide />, bg: 'bg-white' },
  { id: 'colos-benefits', component: <ColosBenefitsSlide />, bg: 'bg-white' },
  { id: 'mi-products', component: <MarkemImajeProductsSlide />, bg: 'bg-white' },
  { id: 'conclusion', component: <ConclusionSlide />, bg: 'bg-[#F9FAFB]' }
];

export default function Presentation() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') {
        nextSlide();
      } else if (e.key === 'ArrowLeft') {
        prevSlide();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentSlide]);

  return (
    <div className="fixed inset-0 bg-[#111827] flex items-center justify-center font-sans overflow-hidden">
      <div className={`relative w-full max-w-[1280px] h-full max-h-[800px] overflow-hidden shadow-2xl transition-colors duration-500 ${slides[currentSlide].bg}`}>
        
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ x: 1000, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -1000, opacity: 0 }}
            transition={{ type: "spring", stiffness: 100, damping: 20 }}
            className="w-full h-full"
          >
            {slides[currentSlide].component}
          </motion.div>
        </AnimatePresence>

        {/* Navigation Overlays */}
        <div className="absolute bottom-6 right-8 flex items-center gap-4 z-50">
          <div className="flex gap-2 mr-4">
            {slides.map((_, i) => (
              <div 
                key={i} 
                className={`h-1.5 rounded-full transition-all duration-300 ${i === currentSlide ? 'w-8 bg-[#2B57A3]' : 'w-2 bg-gray-300'}`}
              />
            ))}
          </div>
          
          <button 
            onClick={prevSlide} 
            disabled={currentSlide === 0}
            className="p-3 bg-white border border-gray-200 rounded-full shadow-md hover:bg-gray-50 disabled:opacity-30 transition-all text-[#2B57A3]"
          >
            <ChevronLeft size={24} />
          </button>
          <button 
            onClick={nextSlide} 
            disabled={currentSlide === slides.length - 1}
            className="p-3 bg-[#2B57A3] text-white rounded-full shadow-lg hover:bg-[#1D4ED8] disabled:opacity-30 transition-all"
          >
            <ChevronRight size={24} />
          </button>
        </div>

        {/* Logo and Context Branding */}
        <div className="absolute bottom-6 left-8 flex items-center gap-4 z-50">
          <div className="flex items-center gap-2 h-8 px-4 bg-white/80 backdrop-blur border border-gray-100 rounded-full shadow-sm">
            <div className="w-4 h-4 bg-[#00AA4D] rounded-sm"></div>
            <span className="text-[10px] font-bold text-gray-600 tracking-wider">MES.Amafil</span>
          </div>
          <div className="h-8 px-4 bg-gray-900 text-white flex items-center rounded-full shadow-lg font-mono text-xs font-bold ring-4 ring-gray-900/10">
            {String(currentSlide + 1).padStart(2, '0')}
          </div>
        </div>
      </div>

      {/* Background Decor */}
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-[#00AA4D]/10 rounded-full blur-3xl -z-10"></div>
      <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-[#2B57A3]/10 rounded-full blur-3xl -z-10"></div>
      
      {/* Footer Info */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-gray-500 text-[10px] font-medium tracking-tighter opacity-50 uppercase">
        Pressione SETAS para navegar · Esc para Sair · Apresentação Chão de Fábrica 4.0
      </div>
    </div>
  );
}
