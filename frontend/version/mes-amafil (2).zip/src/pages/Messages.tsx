import React, { useState, useRef } from 'react';
import { MessageSquare, Search, Send, User, Clock, Check, CheckCheck, MoreVertical, Filter, Terminal, ShieldAlert, Wrench, Package, Image as ImageIcon, Camera, X } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

interface Message {
  id: string;
  sender: string;
  content?: string;
  image?: string;
  timestamp: string;
  status: 'sent' | 'delivered' | 'read';
  group?: string;
  isMe?: boolean;
}

const initialMessages: Message[] = [
  { id: '1', sender: 'Lucas - Manutenção', content: 'Iniciando verificação na empacotadora 04 conforme solicitado.', timestamp: '14:20', status: 'read', group: 'MNT' },
  { id: '2', sender: 'Supervisor - Roberto', content: 'Lote 086 LC liberado para envase.', timestamp: '14:25', status: 'read', group: 'PCP' },
  { id: '3', sender: 'Você', content: 'Ok Roberto, iniciando setup.', timestamp: '14:27', status: 'read', isMe: true },
  { id: '4', sender: 'Lucas - Manutenção', content: 'Peça trocada, máquina em teste por 5 minutos.', timestamp: '15:10', status: 'delivered', group: 'MNT' },
  { id: '5', sender: 'Sistema', content: 'ALERTA: Sensor de temperatura da Estufa 02 atingiu limite superior.', timestamp: '15:15', status: 'delivered', group: 'urgent' },
  { id: '6', sender: 'Roberto Supervisor', content: 'Favor priorizar a OP M01376 de polvilho doce.', timestamp: '15:20', status: 'read', group: 'PCP' },
];

const conversations = [
  { id: 'all', label: 'Geral - Fábrica', icon: Terminal, count: 5, color: 'text-amafil-blue bg-blue-50', description: 'Canal principal de avisos' },
  { id: 'MNT', label: 'Manutenção (MNT)', icon: Wrench, count: 2, color: 'text-red-500 bg-red-50', description: 'Chamados e alertas técnicos' },
  { id: 'PCP', label: 'PCP / Produção', icon: Package, count: 0, color: 'text-amafil-green bg-green-50', description: 'Planejamento e ordens' },
  { id: 'urgent', label: 'Urgentes / Avisos', icon: ShieldAlert, count: 1, color: 'text-orange-500 bg-orange-50', description: 'Alertas críticos de segurança' },
];

export function Messages() {
  const [activeGroup, setActiveGroup] = useState('all');
  const [messages, setMessages] = useState(initialMessages);
  const [newMessage, setNewMessage] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const activeConv = conversations.find(c => c.id === activeGroup) || conversations[0];

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setSelectedImage(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() && !selectedImage) return;

    const msg: Message = {
      id: Date.now().toString(),
      sender: 'Você',
      content: newMessage,
      image: selectedImage || undefined,
      timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      status: 'sent',
      group: activeGroup !== 'all' ? activeGroup : undefined,
      isMe: true
    };

    setMessages([...messages, msg]);
    setNewMessage('');
    setSelectedImage(null);
  };

  const filteredMessages = messages.filter(m => {
    if (activeGroup === 'all') return true;
    return m.group === activeGroup || (m.isMe && !m.group); // Simplified logic for demo
  });

  return (
    <div className="h-[calc(100vh-140px)] flex gap-6 overflow-hidden">
      {/* Sidebar: Conversations */}
      <div className="w-80 flex flex-col gap-4">
        <div className="card-mes p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input 
              type="text" 
              placeholder="Buscar mensagens..." 
              className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-10 pr-4 py-2.5 text-xs font-bold focus:ring-2 focus:ring-amafil-blue/10"
            />
          </div>
        </div>

        <div className="card-mes flex-1 p-2 space-y-1 overflow-y-auto">
          <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-3 py-2 mb-1">Canais de Comunicação</h3>
          {conversations.map((conv) => (
            <button
              key={conv.id}
              onClick={() => setActiveGroup(conv.id)}
              className={cn(
                "w-full flex items-center gap-3 p-3 rounded-2xl transition-all group",
                activeGroup === conv.id 
                  ? "bg-amafil-blue text-white shadow-md shadow-amafil-blue/20" 
                  : "text-gray-600 hover:bg-gray-50"
              )}
            >
              <div className={cn(
                "w-10 h-10 rounded-xl flex items-center justify-center transition-colors",
                activeGroup === conv.id ? "bg-white/20 text-white" : conv.color
              )}>
                <conv.icon className="w-5 h-5" />
              </div>
              <div className="flex-1 text-left">
                <p className={cn("text-xs font-black uppercase tracking-tight", activeGroup === conv.id ? "text-white" : "text-gray-900")}>
                  {conv.label}
                </p>
                <p className={cn("text-[9px] font-bold truncate", activeGroup === conv.id ? "text-white/80" : "text-gray-400")}>
                  Última mensagem às 15:10
                </p>
              </div>
              {conv.count > 0 && activeGroup !== conv.id && (
                <span className="bg-amafil-red text-white text-[8px] font-black px-2 py-1 rounded-full">{conv.count}</span>
              )}
            </button>
          ))}

          <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-3 py-2 mt-4 mb-1">Operadores Ativos</h3>
          <div className="space-y-1 px-1">
             {['Lucas Manutenção', 'Roberto Sup.', 'João Empacot.', 'Ana Lab.'].map(user => (
               <button key={user} className="w-full flex items-center gap-2 p-2 hover:bg-gray-50 rounded-xl transition-all group">
                 <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                 <span className="text-[11px] font-bold text-gray-600 group-hover:text-gray-900">{user}</span>
               </button>
             ))}
          </div>
        </div>
      </div>

      {/* Main: Chat Area */}
      <div className="flex-1 flex flex-col card-mes p-4 relative overflow-hidden">
        {/* Chat Header */}
        <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-4 bg-white/50 backdrop-blur-sm sticky top-0 z-10">
          <div className="flex items-center gap-3">
             <div className={cn(
               "w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-500",
               activeConv.color
             )}>
               <activeConv.icon className="w-6 h-6" />
             </div>
             <div>
               <h2 className="text-xl font-black text-gray-900 italic tracking-tighter">{activeConv.label}</h2>
               <div className="flex items-center gap-2">
                 <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                 <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{activeConv.description}</span>
               </div>
             </div>
          </div>
          <button className="w-10 h-10 rounded-xl hover:bg-gray-50 flex items-center justify-center text-gray-400 transition-colors">
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>

        {/* Messages List */}
        <div className="flex-1 overflow-y-auto space-y-6 px-2 pb-24 custom-scrollbar">
          <AnimatePresence mode="popLayout">
            {filteredMessages.map((msg) => (
              <motion.div 
                layout
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                key={msg.id} 
                className={cn(
                  "flex flex-col max-w-[70%]",
                  msg.isMe ? "ml-auto items-end" : "items-start"
                )}
              >
                {!msg.isMe && (
                  <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest ml-3 mb-1.5 flex items-center gap-2">
                    {msg.sender} 
                    {msg.group && <span className="px-1.5 py-0.5 bg-gray-100 rounded text-[8px] border border-gray-200">[{msg.group}]</span>}
                  </span>
                )}
                
                <div className={cn(
                  "overflow-hidden shadow-sm transition-all hover:shadow-md",
                  msg.isMe 
                    ? "bg-amafil-blue text-white rounded-2xl rounded-tr-none" 
                    : "bg-white text-gray-800 rounded-2xl rounded-tl-none border border-gray-100"
                )}>
                  {msg.image && (
                    <img 
                      src={msg.image} 
                      alt="Imagem Anexada" 
                      className="w-full max-h-64 object-cover cursor-pointer hover:opacity-90 transition-opacity" 
                      referrerPolicy="no-referrer"
                    />
                  )}
                  {msg.content && (
                    <div className="px-5 py-3 text-[13px] font-bold tracking-tight leading-relaxed">
                      {msg.content}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 mt-1.5 px-1">
                  <span className="text-[9px] font-bold text-gray-400 uppercase tracking-tighter">{msg.timestamp}</span>
                  {msg.isMe && (
                    <span className="text-amafil-blue">
                      {msg.status === 'read' ? <CheckCheck className="w-3 h-3" /> : <Check className="w-3 h-3" />}
                    </span>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Chat Input Area */}
        <div className="absolute bottom-4 left-4 right-4 z-20 space-y-2">
          <AnimatePresence>
            {selectedImage && (
              <motion.div 
                initial={{ opacity: 0, y: 10, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.9 }}
                className="relative w-24 h-24 rounded-2xl overflow-hidden border-2 border-amafil-blue shadow-lg mb-2 group"
              >
                <img src={selectedImage} alt="Preview" className="w-full h-full object-cover" />
                <button 
                  onClick={() => setSelectedImage(null)}
                  className="absolute top-1 right-1 w-6 h-6 bg-black/50 text-white rounded-full flex items-center justify-center hover:bg-amafil-red transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="bg-white/90 backdrop-blur-md p-2 rounded-2xl border border-gray-200 flex gap-2 shadow-xl shadow-gray-200/50">
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="w-12 h-12 rounded-xl flex items-center justify-center text-gray-400 hover:bg-gray-100 hover:text-amafil-blue transition-all"
            >
              <ImageIcon className="w-5 h-5" />
            </button>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              onChange={handleImageSelect}
            />
            
            <input 
              type="text" 
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage(e)}
              placeholder={selectedImage ? "Adicione uma legenda..." : `Mensagem para ${activeConv.label}...`}
              className="flex-1 bg-gray-50 border-none rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-amafil-blue/10 placeholder:text-gray-400"
            />
            
            <button 
              onClick={handleSendMessage}
              disabled={!newMessage.trim() && !selectedImage}
              className={cn(
                "w-12 h-12 rounded-xl flex items-center justify-center transition-all",
                (newMessage.trim() || selectedImage)
                  ? "bg-amafil-blue text-white shadow-lg shadow-amafil-blue/30 hover:scale-105 active:scale-95"
                  : "bg-gray-100 text-gray-300 cursor-not-allowed"
              )}
            >
              <Send className="w-5 h-5 -rotate-45" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
