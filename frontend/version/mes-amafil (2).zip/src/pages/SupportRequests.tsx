import React, { useState } from 'react';
import { ClipboardList, MessageSquare, Wrench, Package, Clock, ShieldAlert, Search, Filter, Plus, CheckCircle2, ChevronRight } from 'lucide-react';
import { cn } from '../lib/utils';

interface SupportRequest {
  id: string;
  tipo: 'MANUTENCAO' | 'ALMOXARIFADO' | 'PCP' | 'QUALIDADE';
  titulo: string;
  maquina: string;
  prioridade: 'BAIXA' | 'MEDIA' | 'ALTA' | 'URGENTE';
  status: 'ABERTO' | 'EM_ATENDIMENTO' | 'CONCLUIDO';
  solicitante: string;
  criadoEm: string;
  tempoDeEspera: string;
}

const requests: SupportRequest[] = [
  {
    id: 'REQ-1024',
    tipo: 'MANUTENCAO',
    titulo: 'Vazamento de ar comprimido - Mangueira 04',
    maquina: '30',
    prioridade: 'ALTA',
    status: 'EM_ATENDIMENTO',
    solicitante: 'João Silva',
    criadoEm: '08/05/2026 10:45',
    tempoDeEspera: '22 min'
  },
  {
    id: 'REQ-1023',
    tipo: 'ALMOXARIFADO',
    titulo: 'Solicitação de Fita Adesiva 48x100',
    maquina: '32',
    prioridade: 'MEDIA',
    status: 'ABERTO',
    solicitante: 'Maria Oliveira',
    criadoEm: '08/05/2026 10:55',
    tempoDeEspera: '12 min'
  },
  {
    id: 'REQ-1022',
    tipo: 'PCP',
    titulo: 'Dúvida no apontamento de refugo da OP M01376',
    maquina: '30',
    prioridade: 'BAIXA',
    status: 'CONCLUIDO',
    solicitante: 'Ricardo Nunes',
    criadoEm: '08/05/2026 09:20',
    tempoDeEspera: '45 min'
  },
  {
    id: 'REQ-1021',
    tipo: 'QUALIDADE',
    titulo: 'Amostra de teste de umidade aprovada',
    maquina: '15',
    prioridade: 'URGENTE',
    status: 'ABERTO',
    solicitante: 'Laboratório',
    criadoEm: '08/05/2026 11:02',
    tempoDeEspera: '5 min'
  }
];

export function SupportRequests() {
  const [activeForm, setActiveForm] = useState<null | 'MNT' | 'ALM' | 'PCP'>(null);

  const handleCloseForm = () => setActiveForm(null);

  const FormModal = ({ type, title, children }: { type: string, title: string, children: React.ReactNode }) => (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in duration-200">
        <div className="px-8 py-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
          <div>
            <span className="text-[10px] font-black text-amafil-blue uppercase tracking-widest">{type}</span>
            <h3 className="text-xl font-black text-gray-900 italic tracking-tighter">{title}</h3>
          </div>
          <button onClick={handleCloseForm} className="text-gray-400 hover:text-gray-600 font-black text-xl">×</button>
        </div>
        <div className="p-8 space-y-4">
          {children}
          <div className="pt-4 flex gap-3">
            <button onClick={handleCloseForm} className="flex-1 py-3 px-4 rounded-2xl bg-gray-50 text-gray-500 text-xs font-black uppercase tracking-widest hover:bg-gray-100 transition-all">Cancelar</button>
            <button onClick={() => { alert('Solicitação enviada com sucesso!'); handleCloseForm(); }} className="flex-1 py-3 px-4 rounded-2xl bg-amafil-blue text-white text-xs font-black uppercase tracking-widest shadow-md hover:bg-amafil-blue/90 transition-all">Enviar Solicitação</button>
          </div>
        </div>
      </div>
    </div>
  );

  const typeConfig = {
    MANUTENCAO: { icon: Wrench, color: 'text-red-600', bg: 'bg-red-50', label: 'Manutenção' },
    ALMOXARIFADO: { icon: Package, color: 'text-blue-600', bg: 'bg-blue-50', label: 'Almoxarifado' },
    PCP: { icon: ClipboardList, color: 'text-purple-600', bg: 'bg-purple-50', label: 'PCP' },
    QUALIDADE: { icon: ShieldAlert, color: 'text-cyan-600', bg: 'bg-cyan-50', label: 'Qualidade' },
  };

  const priorityColors = {
    BAIXA: 'text-gray-500',
    MEDIA: 'text-blue-600',
    ALTA: 'text-amber-600',
    URGENTE: 'text-red-700 font-black italic underline'
  };

  const statusStyles = {
    ABERTO: "bg-red-50 text-status-danger border-status-danger/20 animate-pulse",
    EM_ATENDIMENTO: "bg-blue-50 text-blue-700 border-blue-200",
    CONCLUIDO: "bg-green-50 text-status-success border-status-success/20",
  };

  return (
    <div className="space-y-6">
      {/* Modals */}
      {activeForm === 'MNT' && (
        <FormModal type="Solicitação MNT" title="Chamar Manutenção">
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase">Máquina / Equipamento</label>
              <input type="text" placeholder="Ex: Empacotadora 04" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs font-bold" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase">Descrição do Defeito</label>
              <textarea placeholder="Relate o problema observado..." className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs font-bold h-24 resize-none" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase">Prioridade</label>
              <select className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs font-bold">
                <option>Média (Padrão)</option>
                <option>Alta (Parada de Máquina)</option>
                <option>Urgente (Risco de Segurança)</option>
              </select>
            </div>
          </div>
        </FormModal>
      )}

      {activeForm === 'ALM' && (
        <FormModal type="Solicitação ALM" title="Pedido Almoxarifado">
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase">Item Solicitado</label>
              <input type="text" placeholder="Fita, Filme, EPI..." className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs font-bold" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase">Quantidade / Medida</label>
              <input type="text" placeholder="Ex: 2 unidades" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs font-bold" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase">Motivo</label>
              <input type="text" placeholder="Reposição de estoque" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs font-bold" />
            </div>
          </div>
        </FormModal>
      )}

      {activeForm === 'PCP' && (
        <FormModal type="Suporte PCP" title="Dúvida PCP / Apontamento">
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase">Número da OP</label>
              <input type="text" placeholder="Ex: M01376" className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs font-bold" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase">Descreva sua Dúvida</label>
              <textarea placeholder="Dúvida sobre quantidade, refugo, lote..." className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-xs font-bold h-24 resize-none" />
            </div>
          </div>
        </FormModal>
      )}

      {/* Header */}
      <div className="flex justify-between items-end border-b border-bento-border pb-6">
        <div>
          <h1 className="text-4xl font-black tracking-tighter text-gray-900 font-sans italic">Runtime<span className="text-amafil-blue">.Solicitações</span></h1>
          <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px] mt-1">Interação Direta Chão de Fábrica x Apoio (PCP/MNT/ALM/QLD)</p>
        </div>
        <div className="flex gap-3">
          <button className="bg-white border-2 border-bento-border text-gray-600 px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-widest shadow-sm hover:bg-gray-50 transition-all flex items-center gap-2">
            <Filter className="w-4 h-4" />
            Filtrar
          </button>
          <button className="bg-amafil-blue text-white px-6 py-2.5 rounded-full text-xs font-black uppercase tracking-widest hover:bg-amafil-blue/90 transition-all shadow-md flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Nova Solicitação
          </button>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'Pendentes de Início', value: '05', icon: Clock, color: 'text-red-600' },
          { label: 'Em Atendimento', value: '03', icon: Activity, color: 'text-blue-600' },
          { label: 'SLA Médio (Turno)', value: '18m', icon: Gauge, color: 'text-amafil-green' },
          { label: 'Finalizados Hoje', value: '42', icon: CheckCircle2, color: 'text-gray-500' },
        ].map((item, i) => (
          <div key={i} className="card-mes p-5 shadow-sm flex items-center justify-between">
            <div>
              <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">{item.label}</h4>
              <p className={cn("text-3xl font-black italic leading-none", item.color)}>{item.value}</p>
            </div>
            <item.icon className="w-8 h-8 text-gray-100" />
          </div>
        ))}
      </div>

      {/* Main Grid View */}
      <div className="grid grid-cols-12 gap-6">
        {/* Active Requests List */}
        <div className="card-mes col-span-12 lg:col-span-8 p-0 shadow-sm">
          <div className="px-8 py-5 border-b border-bento-border flex justify-between items-center bg-gray-50/50">
            <h3 className="text-xs font-black text-gray-500 uppercase tracking-widest">Atendimento em Tempo Real</h3>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                placeholder="Pesquisar REQ ID..." 
                className="w-full bg-white border border-bento-border rounded-lg py-1.5 pl-9 pr-4 text-xs focus:ring-2 focus:ring-amafil-blue/10 outline-none" 
              />
            </div>
          </div>

          <div className="divide-y divide-gray-100">
            {requests.map((req) => {
              const Config = typeConfig[req.tipo];
              const Icon = Config.icon;
              
              return (
                <div key={req.id} className="p-6 hover:bg-gray-50/50 transition-colors group flex items-center gap-6">
                  <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-sm border", Config.bg, Config.color, "border-current/10")}>
                    <Icon className="w-7 h-7" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{req.id} • Máquina {req.maquina}</span>
                      <span className={cn("text-[9px] font-bold uppercase py-0.5 px-2 rounded-full border", statusStyles[req.status])}>
                        {req.status.replace(/_/g, ' ')}
                      </span>
                    </div>
                    <h4 className="text-base font-bold text-gray-900 group-hover:text-amafil-blue transition-colors truncate italic">{req.titulo}</h4>
                    <p className="text-[11px] font-bold text-gray-400 mt-1 uppercase tracking-tight">Solicitante: <span className="text-gray-600">{req.solicitante}</span> • Prioridade: <span className={priorityColors[req.prioridade]}>{req.prioridade}</span></p>
                  </div>

                  <div className="text-right shrink-0">
                    <p className="text-xs font-black text-amafil-red italic">{req.tempoDeEspera}</p>
                    <p className="text-[10px] font-bold text-gray-400 mt-1">{req.criadoEm.split(' ')[1]}</p>
                  </div>

                  <button className="w-10 h-10 rounded-xl bg-gray-50 flex items-center justify-center text-gray-300 group-hover:bg-white group-hover:text-amafil-blue border border-transparent group-hover:border-bento-border transition-all shadow-sm">
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sidebar Alerts / Tips */}
        <div className="col-span-12 lg:col-span-4 space-y-6">
          <div className="card-mes shadow-sm p-6">
            <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-6">Ações Rápidas</h3>
            <div className="space-y-3">
              <button 
                onClick={() => setActiveForm('MNT')}
                className="w-full h-12 bg-white hover:bg-gray-50 text-gray-700 rounded-2xl flex items-center gap-3 px-4 transition-all text-xs font-bold border border-bento-border shadow-sm group"
              >
                <div className="w-8 h-8 rounded-xl bg-red-50 flex items-center justify-center text-status-danger">
                  <Wrench className="w-4 h-4" />
                </div>
                Chamar Manutenção (MNT)
              </button>
              <button 
                onClick={() => setActiveForm('ALM')}
                className="w-full h-12 bg-white hover:bg-gray-50 text-gray-700 rounded-2xl flex items-center gap-3 px-4 transition-all text-xs font-bold border border-bento-border shadow-sm group"
              >
                <div className="w-8 h-8 rounded-xl bg-blue-50 flex items-center justify-center text-amafil-blue">
                  <Package className="w-4 h-4" />
                </div>
                Pedido Almoxarifado (ALM)
              </button>
              <button 
                onClick={() => setActiveForm('PCP')}
                className="w-full h-12 bg-white hover:bg-gray-50 text-gray-700 rounded-2xl flex items-center gap-3 px-4 transition-all text-xs font-bold border border-bento-border shadow-sm group"
              >
                <div className="w-8 h-8 rounded-xl bg-purple-50 flex items-center justify-center text-purple-600">
                  <ClipboardList className="w-4 h-4" />
                </div>
                Dúvida PCP / Apontamento
              </button>
            </div>
          </div>

          <div className="card-mes p-6 border-dashed border-2 flex flex-col items-center justify-center text-center gap-4 bg-gray-50">
             <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center text-gray-300 border border-bento-border">
               <MessageSquare className="w-6 h-6" />
             </div>
             <div>
               <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Central de Mensagens</p>
               <p className="text-[10px] font-bold text-gray-400">Em breve: chat direto entre operador e equipe técnica.</p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Re-using Gauge/Activity from Production or internal imports if needed
function Activity({ className }: { className?: string }) { return <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>; }
function Gauge({ className }: { className?: string }) { return <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>; }
