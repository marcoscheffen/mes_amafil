import { Play, Pause, Square, FileText, Wrench, Package, AlertCircle, Activity, Gauge, Clock } from 'lucide-react';
import { cn } from '../lib/utils';
import { Machine } from '../types';

const machines: (Machine & { oee: number; availability: number; quality: number; prod: string })[] = [
  { id: '30', codigo: '30', nome: 'Empacotadora Stand-up 30', status: 'OPERANDO', lastOP: 'M01376', oee: 88.5, availability: 92, quality: 99.1, prod: '1,250 CX' },
  { id: '32', codigo: '32', nome: 'Empacotadora Stand-up 32', status: 'OPERANDO', lastOP: 'M01385', oee: 76.2, availability: 80, quality: 98.5, prod: '840 CX' },
  { id: '15', codigo: '15', nome: 'Ensacadeira Automática 15', status: 'PARADA', lastOP: 'M01390', oee: 0, availability: 0, quality: 100, prod: '0 SC' },
  { id: '08', codigo: '08', nome: 'Costuradeira de Sacaria 08', status: 'MANUTENCAO', lastOP: 'M01402', oee: 0, availability: 0, quality: 0, prod: '0 SC' },
  { id: '02', codigo: '02', nome: 'Coladeira de Papelão 02', status: 'OFFLINE', lastOP: '-', oee: 0, availability: 0, quality: 0, prod: '-' },
];

export function Production() {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex justify-between items-end border-b border-bento-border pb-6">
        <div>
          <h1 className="text-4xl font-black tracking-tighter text-gray-900">Live<span className="text-amafil-green">.Produção</span></h1>
          <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px] mt-1">Monitoramento em Tempo Real - Chão de Fábrica</p>
        </div>
        <div className="flex gap-4">
          <div className="bg-white px-5 py-2.5 rounded-full border border-bento-border text-xs font-bold text-gray-500 flex items-center gap-2 shadow-sm">
            <span className="w-2.5 h-2.5 rounded-full bg-status-success animate-pulse shadow-sm"></span>
            Nós Totais: 05
          </div>
          <button className="bg-gray-900 text-white px-6 py-2.5 rounded-full text-xs font-black uppercase tracking-widest hover:bg-gray-800 transition-all shadow-md flex items-center gap-2">
            Configurar Layout
          </button>
        </div>
      </div>

      {/* Critical Alerts Strip */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="card-mes bg-red-50 border-status-danger/20 p-4 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-status-danger flex items-center justify-center text-white shrink-0">
            <AlertCircle className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-[10px] font-black text-status-danger uppercase tracking-widest">Alerta Crítico</h4>
            <p className="text-sm font-bold text-gray-900 italic">Máquina 08 em manutenção mecânica excedida</p>
          </div>
        </div>
        <div className="card-mes bg-amber-50 border-status-warning/20 p-4 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-status-warning flex items-center justify-center text-white shrink-0">
             <Clock className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-[10px] font-black text-status-warning uppercase tracking-widest">Atenção</h4>
            <p className="text-sm font-bold text-gray-900 italic">Setup da OP M01390 atrasado em 15min</p>
          </div>
        </div>
        <div className="card-mes bg-blue-50 border-amafil-blue/20 p-4 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-amafil-blue flex items-center justify-center text-white shrink-0">
             <Activity className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-[10px] font-black text-amafil-blue uppercase tracking-widest">Informação</h4>
            <p className="text-sm font-bold text-gray-900 italic">Troca de turno prevista para as 13:45</p>
          </div>
        </div>
      </div>

      {/* Machine Bento Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {machines.map((machine) => (
          <div key={machine.id} className="card-mes group hover:border-amafil-green/30 flex flex-col p-0 overflow-hidden relative">
            {/* Status Bar Top */}
            <div className={cn(
              "h-2 w-full",
              machine.status === 'OPERANDO' ? "bg-status-success" : 
              machine.status === 'PARADA' ? "bg-status-warning" :
              machine.status === 'MANUTENCAO' ? "bg-status-danger" : "bg-status-offline"
            )} />

            <div className="p-6 flex flex-col h-full">
              {/* Machine Header */}
              <div className="flex justify-between items-start mb-6">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">ID do Nó: {machine.codigo}</span>
                    <span className={cn(
                      "badge-status border shadow-sm",
                      machine.status === 'OPERANDO' ? "bg-green-50 text-status-success border-status-success/20" : 
                      machine.status === 'PARADA' ? "bg-amber-50 text-status-warning border-status-warning/20" :
                      machine.status === 'MANUTENCAO' ? "bg-red-50 text-status-danger border-status-danger/20" : "bg-gray-50 text-status-offline border-border-mes"
                    )}>
                      {machine.status}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold tracking-tight text-gray-900 italic">{machine.nome}</h3>
                </div>
                {machine.status === 'OPERANDO' && (
                  <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center">
                    <Activity className="w-5 h-5 text-status-success animate-pulse" />
                  </div>
                )}
              </div>

              {/* OP Badge - Terminal Style */}
              <div className="bg-gray-900 rounded-xl p-3 mb-6 flex justify-between items-center border border-gray-800">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-amafil-green" />
                  <span className="text-xs font-mono font-bold text-gray-400">OP_EM_EXECUÇÃO:</span>
                  <span className="text-xs font-mono font-black text-amafil-green tracking-widest">{machine.lastOP}</span>
                </div>
                <span className="bg-gray-800 text-[9px] font-bold text-gray-500 uppercase px-2 py-0.5 rounded">v1.2</span>
              </div>

              {/* Stats Bar */}
              <div className="grid grid-cols-3 gap-2 mb-8">
                <div className="bg-gray-50 p-3 rounded-2xl border border-bento-border text-center">
                  <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">OEE</p>
                  <p className={cn(
                    "text-lg font-black italic",
                    machine.oee >= 85 ? "text-status-success" : machine.oee >= 70 ? "text-status-warning" : "text-status-danger"
                  )}>{machine.oee}%</p>
                </div>
                <div className="bg-gray-50 p-3 rounded-2xl border border-bento-border text-center">
                  <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Disponib.</p>
                  <p className="text-lg font-black text-gray-900 italic">{machine.availability}%</p>
                </div>
                <div className="bg-gray-50 p-3 rounded-2xl border border-bento-border text-center">
                  <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1">Qualidade</p>
                  <p className="text-lg font-black text-amafil-blue italic">{machine.quality}%</p>
                </div>
              </div>

              {/* Action Area */}
              <div className="mt-auto pt-6 border-t border-bento-border flex gap-3">
                <button className="flex-1 h-12 flex items-center justify-center gap-2 bg-white border-2 border-bento-border text-gray-500 rounded-2xl hover:bg-gray-50 hover:text-gray-900 text-xs font-black uppercase tracking-widest transition-all">
                  <Wrench className="w-4 h-4" />
                  Logs
                </button>
                <button className={cn(
                  "flex-[1.5] h-12 flex items-center justify-center gap-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all shadow-md group-hover:scale-[1.02]",
                  machine.status === 'OPERANDO' 
                    ? "bg-amafil-green text-white hover:bg-amafil-green/90 shadow-amafil-green/20" 
                    : "bg-gray-900 text-white hover:bg-gray-800 shadow-gray-900/20"
                )}>
                  <Gauge className="w-4 h-4" />
                  Monitorar
                </button>
              </div>
            </div>

            {/* Inactive Overlays */}
            {(machine.status === 'OFFLINE') && (
              <div className="absolute inset-x-0 bottom-0 top-2 bg-gray-50/60 backdrop-blur-[1px] flex items-center justify-center z-10">
                <div className="bg-white border-2 border-bento-border px-4 py-2 rounded-full text-[10px] font-black text-gray-400 uppercase tracking-widest shadow-xl">
                  Node Desconectado
                </div>
              </div>
            )}
            {(machine.status === 'MANUTENCAO') && (
              <div className="absolute inset-x-0 bottom-0 top-2 bg-red-50/20 backdrop-blur-[1px] flex items-center justify-center z-10">
                <div className="bg-white border-2 border-status-danger/30 px-4 py-2 rounded-full text-[10px] font-black text-status-danger uppercase tracking-widest shadow-xl flex items-center gap-2 animate-bounce">
                  <Wrench className="w-3.5 h-3.5" />
                  Ajuste Técnico em Andamento
                </div>
              </div>
            )}
          </div>
        ))}

        {/* Add Machine - Bento Style */}
        <button className="card-mes border-2 border-dashed border-gray-300 flex flex-col items-center justify-center p-12 gap-4 text-gray-400 hover:text-amafil-green hover:border-amafil-green hover:bg-green-50/20 transition-all cursor-pointer group">
          <div className="w-16 h-16 rounded-3xl bg-gray-50 flex items-center justify-center group-hover:bg-green-100 transition-all duration-300 group-hover:rotate-12">
            <Package className="w-8 h-8" />
          </div>
          <div className="text-center">
            <p className="text-sm font-black uppercase tracking-widest mb-1">Provisionar Nó</p>
            <p className="text-xs font-bold text-gray-400">Adicionar nova linha ao cluster</p>
          </div>
        </button>
      </div>
    </div>
  );
}
