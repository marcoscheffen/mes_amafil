import { Bell, Search, User } from 'lucide-react';

export function Header() {
  return (
    <header className="h-20 bg-white border-b border-bento-border sticky top-0 z-40 px-8 flex items-center justify-between">
      <div className="flex items-center gap-6 flex-1">
        <p className="text-gray-400 font-bold uppercase tracking-widest text-[10px]">Unidade: amafil-pcp-01</p>
        <div className="relative w-full max-w-md">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input 
            type="text" 
            placeholder="Buscar processos, OPs ou máquinas..." 
            className="w-full bg-gray-50 border border-bento-border rounded-full py-2.5 pl-12 pr-4 text-sm text-gray-900 placeholder:text-gray-400 focus:ring-2 focus:ring-[#2563EB]/10 focus:border-[#2563EB]/50 outline-none transition-all shadow-inner"
          />
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2 px-4 py-1.5 bg-green-50 text-amafil-green rounded-full text-[10px] font-black tracking-widest border border-amafil-green/20">
          <span className="w-2 h-2 rounded-full bg-amafil-green animate-pulse"></span>
          LIVE SYSTEM
        </div>
        
        <button className="p-2.5 text-gray-400 hover:bg-gray-50 hover:text-gray-700 rounded-xl border border-transparent hover:border-bento-border transition-all relative">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-amafil-red rounded-full border-2 border-white"></span>
        </button>
        
        <div className="w-px h-8 bg-bento-border mx-2" />
        
        <div className="flex items-center gap-4">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-bold text-gray-900 tracking-tight">Fécula Amafil</p>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Cianorte - PR</p>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-gray-100 flex items-center justify-center text-gray-500">
            <User className="w-5 h-5" />
          </div>
        </div>
      </div>
    </header>
  );
}
