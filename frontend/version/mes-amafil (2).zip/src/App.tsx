import { Routes, Route, useLocation } from 'react-router-dom';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { Dashboard } from './pages/Dashboard';
import { Production } from './pages/Production';
import { OrderList } from './pages/OrderList';
import { DowntimeList } from './pages/DowntimeList';
import { SupportRequests } from './pages/SupportRequests';
import { Reports } from './pages/Reports';
import { Users } from './pages/Users';
import { Settings } from './pages/Settings';
import { Messages } from './pages/Messages';
import { ProductionExecution } from './pages/ProductionExecution';
import { motion, AnimatePresence } from 'motion/react';

function Layout() {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-bento-bg">
      <Sidebar currentPath={location.pathname} />
      
      <div className="pl-64">
        <Header />
        
        <main className="p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.02 }}
              transition={{ duration: 0.2 }}
            >
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/producao" element={<Production />} />
                <Route path="/ops" element={<OrderList />} />
                <Route path="/paradas" element={<DowntimeList />} />
                <Route path="/operacao" element={<ProductionExecution />} />
                <Route path="/solicitacoes" element={<SupportRequests />} />
                <Route path="/relatorios" element={<Reports />} />
                <Route path="/usuarios" element={<Users />} />
                <Route path="/mensagens" element={<Messages />} />
                <Route path="/config" element={<Settings />} />
              </Routes>
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/*" element={<Layout />} />
    </Routes>
  );
}
